# City Data

Flags and data taken from wikipedia: 

http://en.wikipedia.org/wiki/List_of_cities_proper_by_population

# Remove Icon

Created by the author
